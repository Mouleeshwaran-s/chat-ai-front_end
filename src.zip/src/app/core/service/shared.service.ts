import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  constructor(private https: HttpClient) {
    https.get('').subscribe((data: any) => {
    });
  }
  private sidebarToggleSourceChatToSide = new Subject<void>();
  private sidebarToggleSourceSideToChat = new Subject<void>();
  sidebarToggle$ = this.sidebarToggleSourceChatToSide.asObservable();
  sidebarToggleSide$ = this.sidebarToggleSourceSideToChat.asObservable();
  // Method to trigger the sidebar toggle from chat to side
  triggerSidebarToggleSideToChat() {
    this.sidebarToggleSourceSideToChat.next();
  }
  // Method to trigger the sidebar toggle from side to chat
  triggerSidebarToggle() {
    this.sidebarToggleSourceChatToSide.next();
  }

  private userSetSource = new Subject<any>();
  userSet$ = this.userSetSource.asObservable();

  triggerUserSet(user: any) {
    this.userSetSource.next(user);
  }

  private sessionSelectedSource = new Subject<string>();
  sessionSelected$ = this.sessionSelectedSource.asObservable();

  triggerSessionSelected(sessionId: string) {
    this.sessionSelectedSource.next(sessionId);
  }
}
