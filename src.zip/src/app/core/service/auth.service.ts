import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private readonly API_BASE_URL = 'http://localhost:8082/api/auth';

    private ACCESS_TOKEN_KEY = 'access_token';
    private REFRESH_TOKEN_KEY = 'refresh_token';

    constructor(
        private http: HttpClient,
        private router: Router
    ) { }

    /** -----------------------------
     *  Authentication APIs
     *  ----------------------------- */
    login(credentials: { username: string; password: string; }): Observable<any> {
        return this.http.post(`${this.API_BASE_URL}/login`, credentials).pipe(
            tap((response: any) => {
                this.saveAccessToken(response.token);
                this.saveRefreshToken(response.refreshToken);
            })
        );
    }

    refreshToken(): Observable<any> {
        const refreshToken = this.getRefreshToken();
        if (!refreshToken) throw new Error('No refresh token found');
        return this.http.post(`${this.API_BASE_URL}/refresh-token`, { refreshToken });
    }

    logout(): void {
        this.clearTokens();
        this.router.navigate(['/login']);
    }

    /** -----------------------------
     *  Token Utilities
     *  ----------------------------- */
    saveAccessToken(token: string): void {
        localStorage.setItem(this.ACCESS_TOKEN_KEY, token);
    }

    saveRefreshToken(token: string): void {
        localStorage.setItem(this.REFRESH_TOKEN_KEY, token);
    }

    getAccessToken(): string | null {
        return localStorage.getItem(this.ACCESS_TOKEN_KEY);
    }

    getRefreshToken(): string | null {
        return localStorage.getItem(this.REFRESH_TOKEN_KEY);
    }

    clearTokens(): void {
        localStorage.removeItem(this.ACCESS_TOKEN_KEY);
        localStorage.removeItem(this.REFRESH_TOKEN_KEY);
    }

    isLoggedIn(): boolean {
        return !!this.getAccessToken();
    }
}
