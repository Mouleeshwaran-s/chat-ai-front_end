import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { SharedService } from '../../core/service/shared.service';
import { SidebarService } from './service/sidebar.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  imports: [
    CommonModule,
    RouterModule
  ],
})
export class SidebarComponent implements OnInit {
  title = 'chatAI';
  sidebarClosed = false;
  chatHistory: any[] = [];

  constructor(private service: SidebarService, private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sidebarClosed = JSON.parse(sessionStorage.getItem('sidebarClosed') || 'false');
    this.sharedService.sidebarToggle$.subscribe(() => {
      this.toggleSidebar();
    });
    this.sharedService.userSet$.subscribe(user => {
      this.getChatHistory();
    });
    this.getChatHistory();
  }

  toggleSidebar() {
    this.sidebarClosed = !this.sidebarClosed;
    sessionStorage.setItem('sidebarClosed', JSON.stringify(this.sidebarClosed));
    this.sharedService.triggerSidebarToggleSideToChat();
  }

  getChatHistory() {
    const user = JSON.parse(sessionStorage.getItem('user') || '');
    const userId = user?.uuid || '';
    this.service.getChatHistory(userId).subscribe((history: any) => {
      console.log('Chat history:', history);
      this.chatHistory = history;
    }, (error) => {
      console.error('Error fetching chat history:', error);
      this.chatHistory = [];
    });
  }
  setActiveSession(session: any) {
    sessionStorage.setItem('generated_id', session);
    this.sharedService.triggerSessionSelected(session); // Add this line
  }
}
