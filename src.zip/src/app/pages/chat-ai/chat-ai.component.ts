import {
  AfterViewChecked,
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  OnInit,
  Output,
  EventEmitter,
  ViewChild,
  ChangeDetectorRef,
  OnDestroy
} from '@angular/core';
import { FormControl, FormsModule, Validators } from '@angular/forms';
import { MaterialModule } from '../../core/modules/material/material.module';
import { CommonModule } from '@angular/common';
import { saveAs } from 'file-saver';
import { MarkdownModule } from 'ngx-markdown';
import { marked } from 'marked';
import { ChatAiService } from './service/chat-ai.service';
import { Router } from '@angular/router';
import { SharedService } from '../../core/service/shared.service';
import { lastValueFrom } from 'rxjs';
import * as mammoth from 'mammoth';
import * as pdfjsLib from 'pdfjs-dist';
import { Document, Packer, Paragraph, HeadingLevel, TextRun, Table, TableRow, TableCell, WidthType, BorderStyle, AlignmentType } from "docx";
import { models } from '../../core/models/ai-models';
import { PuterService } from './service/puter.service';
declare const puter: any;
interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  isText: boolean;
  isImage: boolean;
  isAttachment: boolean;
  filesData?: {
    data: any[];
    totalCount: number;
    otherFileData: any[];
  };
}
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface MessagePayload {
  session_id: string;
  request_id: string;
  uuid: string;
  role: string;
  messages: ChatMessage[];
  isText: boolean;
  isImage: boolean;
  date_time: string; // ISO 8601 string
}

interface PuterMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}
@Component({
  selector: 'app-chat-ai',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    MarkdownModule,
    FormsModule
  ],
  templateUrl: './chat-ai.component.html',
  styleUrl: './chat-ai.component.css'
})
export class ChatAIComponent implements AfterViewInit, OnInit, AfterViewChecked, OnDestroy {
  imageValue: any = '';
  docValue: any = '';
  @ViewChild('chatContainer') private chatContainer!: ElementRef;
  @ViewChild('autoTextarea') autoTextarea!: ElementRef<HTMLTextAreaElement>;
  selectedModel = new FormControl('gpt-4o', [Validators.required]);
  selectedType = new FormControl('chat', [Validators.required]);
  models = models;
  prompt = '';
  isProgress = false;
  messages: Message[] = [];
  payLoadMessages: MessagePayload = {
    session_id: '',
    request_id: '',
    uuid: '',
    role: '',
    messages: [],
    isText: false,
    isImage: false,
    date_time: ''
  };
  puterMessages: PuterMessage[] = [];
  isAuthenticated = true;
  isSidebarVisible = true;
  user: any;
  path = '';
  private isUserAtBottom = true;
  @Output() sidebarToggle = new EventEmitter<void>();
  sessionId: any;
  response: string = '';
  isLoading: boolean = false;
  constructor(
    private chatAIService: ChatAiService,
    private puterService: PuterService,
    private router: Router,
    private sharedService: SharedService,
    private cdr: ChangeDetectorRef
  ) {
    (pdfjsLib as any).GlobalWorkerOptions.workerSrc = '/assets/scripts/pdf.worker.min.mjs';
  }
  ngOnInit(): void {
    console.log("ngOnInit called");
    const markdownText = "# Welcome to the Markdown Guide 🎉\n\nMarkdown is a lightweight markup language with plain-text formatting syntax. It's easy to learn and widely used.\n\n## Basic Text Formatting\n\n- **Bold** text: `**text**` or `__text__`\n- *Italic* text: `*text*` or `_text_`\n- ***Bold and Italics***: `***text***`\n- ~~Strikethrough~~: `~~text~~`\n\n## Lists\n\n### Unordered List\n\n- Item 1\n- Item 2\n  - Subitem 1\n  - Subitem 2\n\n### Ordered List\n\n1. First item\n2. Second item\n   1. Sub-item 1\n   2. Sub-item 2\n\n## Links and Images\n\n- [Link to OpenAI](https://www.openai.com)\n- ![Image of Markdown Logo](https://markdown-here.com/img/icon256.png)\n\n## Code\n\n### Inline Code\n\nUse the `print()` function in Python.\n\n### Code Blocks\n\n```python\ndef greet(name):\n    return f\"Hello, {name}!\"\n\nprint(greet(\"World\"))\n```\n\n## Blockquotes \n\n> This is a blockquote.\n> \n> Multiline blockquotes can be nested by adding `>` on each new line.\n\n## Tables\n\n| Name       | Age | Occupation  |\n|------------|-----|-------------|\n| John Doe   | 30  | Developer   |\n| Jane Smith | 25  | Designer    |\n\n## Horizontal Rule\n\n---\n\n## Task Lists\n\n- [x] Complete project proposal\n- [ ] Review feedback\n- [ ] Submit final draft\n\n## Emojis\n\nEnjoy using Markdown! 😄👍\n\n";
    const sample: Message = {
      role: 'assistant',
      content: markdownText,
      isText: true,
      isImage: false,
      isAttachment: false,
      filesData: {
        data: [],
        totalCount: 0,
        otherFileData: []
      }
    };
    // this.messages.push(sample);
    const text = "You are a helpful, intelligent, and professional AI assistant 🤖.\nYour primary goal is to understand and respond to user input clearly, accurately, and efficiently.\n\nPlease follow these core principles:\n\n    - 💬 Respond in a friendly, respectful, and professional tone at all times.\n**Format Requirements:** - Always respond in **Markdown format** for clarity and structure\n - 😀 Include **emojis** where appropriate to enhance tone and engagement.";
    const systemMessage: Message = {
      role: 'system',
      content: text,
      isText: true,
      isImage: false,
      isAttachment: false,
      filesData:
      {
        data: [],
        totalCount: 0,
        otherFileData: []
      }

    };
    this.payLoadMessages = {
      session_id: this.generateId(),
      request_id: this.generateId(),
      uuid: 'user-uuid',
      role: 'system',
      messages: [{ role: 'assistant', content: text }],
      isText: true,
      isImage: false,
      date_time: new Date().toISOString()
    };
    this.puterMessages.push(systemMessage);
    this.isSidebarVisible = JSON.parse(sessionStorage.getItem('sidebarClosed') || 'false');
    this.prompt = sessionStorage.getItem('prompt') || '';
    console.log("isSidebarVisible", this.isSidebarVisible);
    this.sharedService.sidebarToggleSide$?.subscribe(() => {
      setTimeout(() => this.isSidebarVisible = !this.isSidebarVisible, 100);
    });
    const storedId = sessionStorage.getItem('generated_id');
    if (storedId) {
      this.path = `/chat/${storedId}`;
    } else {
      const generatedId = this.generateId();
      sessionStorage.setItem('generated_id', generatedId);
      this.path = `/chat/${generatedId}`;
    }
    console.log('Generated ID:', this.path);
    this.router.navigate([this.path]);
    // console.log("Is Authenticated:", this.isAuthenticated);
    // this.puterService.isSignedIn().then((authenticated: boolean) => {
    //   console.log('Puter Authenticated:', authenticated);
    //   this.isAuthenticated = authenticated;
    //   if (!this.isAuthenticated) {
    //     puter.auth.signIn().then((res: any) => {
    //       this.user = { ...res };
    //       sessionStorage.setItem('user', JSON.stringify(this.user));
    //       delete this.user.featureFlags;
    //       this.sharedService.triggerUserSet(this.user); // <--- Add this line
    //     });
    //   } else {
    //     puter.auth.getUser().then((res: any) => {
    //       this.user = { ...res };
    //       delete this.user.featureFlags;
    //       sessionStorage.setItem('user', JSON.stringify(this.user));
    //       this.sharedService.triggerUserSet(this.user); // <--- Add this line
    //       // this.chatAIService.createUser(this.user).subscribe();
    //       this.getChatHistoryBySessionId();
    //     });
    //   }
    // });
    this.sharedService.sessionSelected$.subscribe(sessionId => {
      this.setPathFromSidebar(`/chat/${sessionId}`);
    });
  }
  ngAfterViewInit(): void {
    // console.log('ngAfterViewInit called');
    if (this.autoTextarea?.nativeElement) {
      this.autoResizeTextarea(this.autoTextarea.nativeElement);
    } setTimeout(() => {
      // console.log('ngAfterViewInit called, scrolling to bottom');
      this.onResize({ target: window });
    }, 100);
  }
  ngAfterViewChecked(): void {
    // console.log('ngAfterViewChecked called');
    if (this.isUserAtBottom) {
      this.scrollToBottom();
      // console.log('Scrolled to bottom after view checked');
      this.onResize({ target: window });
    }
  }
  setPathFromSidebar(path: string): void {
    this.path = path;
    this.getChatHistoryBySessionId();
  }
  getChatHistoryBySessionId(): void {
    this.sessionId = this.path.substring(6);
    // this.chatAIService.getUserChatHistory(this.user.uuid, this.sessionId).subscribe(chat => {
    //   if (chat?.history?.length) {
    //     this.messages = chat.history.map((message: any) => ({
    //       role: message.role,
    //       content: message.content,
    //       isText: message.isText,
    //       isImage: message.isImage
    //     }));
    //   } else {
    //     const systemMessage: Message = {
    //       role: 'system',
    //       content: 'You are a helpful assistant. Provide the output in a Markdown-formatted style also add emojis where appropriate.',
    //       isText: true,
    //       isImage: false
    //     };
    //     this.messages.push(systemMessage);
    //     console.log('Chat History');
    //     this.onResize({ target: window });
    //     this.saveChat(systemMessage.role, systemMessage.content, systemMessage.isText, systemMessage.isImage);
    //   }
    // });
  }
  onScroll(event: Event): void {
    const element = event.target as HTMLElement;
    this.isUserAtBottom = element.scrollHeight - element.scrollTop <= element.clientHeight + 1;
  }
  private scrollToBottom(): void {
    try {
      if (this.chatContainer?.nativeElement) {
        this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
      }
    } catch (err) {
      console.error(err);
    }
  }
  saveChat(role: string, content: string, isText: boolean, isImage: boolean): void {
    const chat = {
      session_id: this.path.substring(6),
      request_id: this.generateId(),
      uuid: this.user?.uuid || '',
      role,
      content,
      isText,
      isImage
    };
    // this.chatAIService.saveChat(chat).subscribe();
  }
  async saveTitle(title: any): Promise<void> {
    const chatHistory = {
      session_id: this.path.substring(6),
      uuid: this.user?.uuid || '',
      title: title
    };
    // await lastValueFrom(this.chatAIService.saveChatHistory(chatHistory));
  }
  // startStreaming(prompt: string) {
  //   this.responseText = '';
  //   this.eventSource = this.chatAIService.streamChat(prompt);

  //   this.eventSource.onmessage = (event) => {
  //     if (event.data === '[DONE]') {
  //       this.eventSource?.close();
  //       return;
  //     }

  //     try {
  //       const parsed = JSON.parse(event.data);
  //       console.log('Received SSE data:', parsed);

  //       const content = parsed?.choices[0].delta.content;
  //       console.log('Parsed content:', content);

  //       if (content) {
  //         this.responseText += content;
  //         this.cdr.detectChanges(); // Trigger change detection to update the view
  //       }
  //     } catch (err) {
  //       console.error('Error parsing SSE data:', err);
  //     }
  //   };

  //   this.eventSource.onerror = (error) => {
  //     console.error('Streaming error:', error);
  //     this.eventSource?.close();
  //   };
  // }
  async askGPT(): Promise<void> {
    const trimmedPrompt = this.prompt.trim();
    const hasPrompt = !!trimmedPrompt;
    const hasFiles = this.filesData.some(file => file.value.trim());

    if (!hasPrompt && !hasFiles) return;

    this.isProgress = true;

    // Compose full user prompt
    let userPrompt = '';
    if (hasPrompt) userPrompt += trimmedPrompt + '\n';

    let fullText = '';
    if (hasFiles) {
      this.filesData.forEach(file => {
        const value = file.value.trim();
        if (value) fullText += value + '\n';
      });
      userPrompt += fullText;
    }
    userPrompt = userPrompt.trim();

    console.log('%c[askGPT] Final Prompt:', 'color: blue;', userPrompt);

    // Prepare user message block
    const isAttachment = hasFiles;
    const userMessage: Message = {
      role: 'user',
      content: isAttachment ? '' : userPrompt,
      isText: true,
      isImage: false,
      isAttachment,
      filesData: {
        data: [],
        totalCount: 0,
        otherFileData: []
      }
    };

    if (isAttachment) {
      const processed = this.processFilesData(this.filesData);
      userMessage.filesData = {
        data: processed.filesData.data,
        totalCount: processed.totalCount,
        otherFileData: processed.otherFileData
      };
    }

    // Push user message and update state
    this.messages.push(userMessage);
    this.puterMessages.push({ role: 'user', content: userPrompt });
    this.prompt = '';
    this.filesData = [];

    const payload: MessagePayload = {
      session_id: 'session123',
      request_id: 'req789',
      uuid: 'user-456',
      role: 'user',
      messages: [
        { role: 'user', content: 'Hello, how are you?' },
        { role: 'assistant', content: 'I\'m great, thank you!' },
        { role: 'user', content: 'I need your help' }
      ],
      isText: true,
      isImage: false,
      date_time: new Date().toISOString()
    };
    this.payLoadMessages.messages.push({ role: 'user', content: userPrompt });
    console.log('Payload Messages:', this.payLoadMessages);
    this.messages.push({
      role: 'assistant',
      content: '',
      isText: true,
      isImage: false,
      isAttachment: isAttachment,
      filesData: {
        data: [],
        totalCount: 0,
        otherFileData: []
      }
    });
    try {
      this.chatAIService.streamChat(
        this.payLoadMessages,
        (chunk) => {
          console.log('Chunk received:', chunk);

          try {
            const parsed = JSON.parse(chunk);
            const deltaContent = parsed?.choices?.[0]?.delta?.content;
            if (deltaContent) {
              const lastMessage = this.messages[this.messages.length - 1];
              lastMessage.content += deltaContent;
              this.cdr.detectChanges();
            }
          } catch (e) {
            console.warn('Non-JSON or malformed chunk:', chunk);
          }
        },
        (err) => {
          console.error('Streaming error:', err);
        }
      );
      // this.chatAIService.streamChat(message).subscribe({
      //   next: (chunk) => {
      //     console.log("Chunk:", chunk); // append to chat
      //     let chunkObject = '';
      //     if (chunk && chunk.startsWith('data:')) {
      //       chunkObject = JSON.parse(chunk.slice(5));
      //     }
      //     console.log("Chunk Object:", chunkObject);
      //     if (chunkObject) {
      //       const parsed = JSON.parse(chunkObject);
      //       console.log('Parsed SSE data:', parsed);
      //       const deltaContent = parsed?.choices[0]?.delta?.content;
      //       if (deltaContent) {
      //         const lastMessage = this.messages[this.messages.length - 1];
      //         lastMessage.content += deltaContent;
      //         this.cdr.detectChanges();
      //       }
      //     }
      //   },
      //   error: (err) => console.error('Stream error:', err),
      //   complete: () => console.log('Stream completed')
      // });
      // this.eventSource = this.chatAIService.streamChat(message);
      // // Push placeholder assistant message
      // this.messages.push({
      //   role: 'assistant',
      //   content: '',
      //   isText: true,
      //   isImage: false,
      //   isAttachment: false,
      //   filesData: {
      //     data: [],
      //     totalCount: 0,
      //     otherFileData: []
      //   }
      // });
      // this.eventSource.onmessage = (event) => {
      //   if (event.data === '[DONE]') {
      //     this.eventSource?.close();
      //     return;
      //   }

      //   try {
      //     const parsed = JSON.parse(event.data);
      //     const deltaContent = parsed?.choices[0]?.delta?.content;

      //     if (deltaContent) {
      //       const lastMessage = this.messages[this.messages.length - 1];
      //       lastMessage.content += deltaContent;
      //       this.cdr.detectChanges();
      //     }
      //   } catch (err) {
      //     console.error('[askGPT] Error parsing SSE data:', err);
      //   }
      // };

      // this.eventSource.onerror = (err) => {
      //   console.error('[askGPT] Streaming error:', err);
      //   this.eventSource?.close();
      // };

    } catch (error) {
      console.error('[askGPT] Chat stream error:', error);

      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, something went wrong.',
        isText: true,
        isImage: false,
        isAttachment: false,
        filesData: {
          data: [],
          totalCount: 0,
          otherFileData: []
        }
      };

      this.messages.push(errorMessage);
      this.puterMessages.push({ role: 'assistant', content: errorMessage.content });
      this.saveChat('assistant', errorMessage.content, true, false);
    } finally {
      this.isProgress = false;
    }
  }

  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }
  filesData: any[] = [];
  pdfValue = '';
  convertFileToBase64(file: File): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        // reader.result will be like "data:image/png;base64,...."
        resolve(reader.result as string);
      };
      reader.onerror = error => reject(error);
    });
  }
  waitForPuter(): Promise<void> {
    return new Promise((resolve) => {
      const check = () => {
        // @ts-ignore
        if (window.puter && window.puter.ai) {
          resolve();
        } else {
          setTimeout(check, 100);
        }
      };
      check();
    });
  }
  async removeFile(file: any) {
    const index = this.filesData.indexOf(file);
    if (index > -1) {
      this.filesData.splice(index, 1);
    }
    console.log(this.filesData);
    this.docValue = "";
    this.pdfValue = "";
    this.imageValue = "";
    this.autoResizeTextarea(this.autoTextarea.nativeElement);
    await this.getAttachmentValue();
    const fullText = this.docValue + "\n" + this.pdfValue + "\n" + this.imageValue;
    console.log("Full Text:", fullText);
  }
  async onFileSelected(event: any) {
    const files: FileList = event.target.files;
    this.autoResizeTextarea(this.autoTextarea.nativeElement);
    if (files && files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        let previewUrl = '';
        if (file.type.startsWith('image/')) {
          previewUrl = URL.createObjectURL(file);
        }
        this.filesData.push({
          file: file,
          name: file.name,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified,
          previewUrl,
          value: ''
        });
      }
      this.autoResizeTextarea(this.autoTextarea.nativeElement);
    }
    await this.getAttachmentValue();
    const fullText = this.docValue + "\n" + this.pdfValue + "\n" + this.imageValue;
    console.log("Full Text:", fullText);
  }
  async getAttachmentValue() {
    this.docValue = "";
    this.pdfValue = "";
    this.imageValue = "";
    if (this.filesData && this.filesData.length > 0) {
      for (let i = 0; i < this.filesData.length; i++) {
        const file = this.filesData[i].file;
        if (file.type.startsWith('image/') && this.filesData[i].value === '') {
          const base64 = await this.convertFileToBase64(file);
          // Wait for Puter to be ready
          await this.waitForPuter();
          // @ts-ignore
          let imageValue = "Image: \n\n" + await puter.ai.img2txt(base64);
          imageValue = imageValue.replace(/^\s*[\r\n]/gm, ''); // regex to remove newlines ^$\n
          this.filesData[i].value = imageValue;
          console.log("Image Value:", imageValue);
        }
        if (file && file.name.endsWith('.docx') && this.filesData[i].value === '') {
          const reader = new FileReader();
          reader.onload = async (e: any) => {
            const arrayBuffer = e.target.result;
            mammoth.extractRawText({ arrayBuffer })
              .then(result => {
                let docValue = "Document Name: " + file.name + "\n\n" + result.value; // The text content
                // regex to remove newlines ^$\n
                docValue = docValue.replace(/^\s*[\r\n]/gm, '');
                this.filesData[i].value = docValue; // The text content
                console.log("Document Value:", docValue);
              })
              .catch(err => {
                console.error('Error reading docx:', err);
              });
          };
          reader.readAsArrayBuffer(file);
        }
        if (file && file.type === 'application/pdf' && this.filesData[i].value === '') {
          const reader = new FileReader();
          reader.onload = async (e: any) => {
            const typedArray = new Uint8Array(e.target.result);
            try {
              const pdf = await pdfjsLib.getDocument(typedArray).promise;
              let textContent = '';
              for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                const page = await pdf.getPage(pageNum);
                const content = await page.getTextContent();
                const pageText = content.items.map((item: any) => item.str).join(' ');
                textContent += pageText + '\n';
              }
              let pdfValue = "Pdf Name: " + file.name + "\n\n" + textContent;
              pdfValue = pdfValue.replace(/^\s*[\r\n]/gm, ''); // regex to remove newlines ^$\n
              this.filesData[i].value = pdfValue;
              console.log("PDF Value:", pdfValue);

            } catch (error) {
              console.error('Error reading PDF:', error);
            }
          };
          reader.readAsArrayBuffer(file);
        } else {
          // alert('Please select a PDF file');
        }
      }
    }
  }
  async imageGenerationGPT(query: string, testMode: boolean = false): Promise<string> {
    if (!query.trim()) return 'Empty input.';
    try {
      const response = await this.puterService.generateImage(query);
      this.messages.push({
        ...response,
        isAttachment: false,
        filesData: {
          data: [],
          totalCount: 0,
          otherFileData: []
        }
      });
      return 'Image generated successfully.';
    } catch (error) {
      console.error(error);
      return 'Image generation error.';
    }
  }
  async handleSubmit(): Promise<void> {
    if (this.isProgress) return;
    this.autoTextarea.nativeElement.style.height = 'auto';
    const type = this.selectedType.value;
    if (type === 'chat') {
      await this.askGPT();
    } else if (type === 'txt-img') {
      await this.imageGenerationGPT(this.prompt);
    }
    this.prompt = '';
    sessionStorage.setItem('prompt', this.prompt);
  }
  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent): void {
    if (event.ctrlKey && event.key === 'Enter') {
      event.preventDefault();
    } else if (event.shiftKey && event.key === 'Enter') {
      // Do NOT add this.prompt += '\n'; Let the browser handle it.
      // Remove event.preventDefault(); so the textarea inserts a newline.
      // Optionally, you can keep event.stopPropagation() if needed.
      console.log('Shift + Enter pressed', this.prompt);
    } else if (event.key === 'Enter') {
      this.handleSubmit();
      console.log("Enter pressed", this.prompt);

      event.preventDefault();
    } else if (event.key === 'Escape') {
      this.prompt = '';
      event.preventDefault();
    } else if (event.ctrlKey && event.key === 'Backspace') {
      this.prompt = this.prompt.trimEnd().replace(/\s+\S*$/, '');
      event.preventDefault();
    }
    // else if (event.key === 'ArrowUp') {
    //   const lastMsg = [...this.messages].reverse().find(msg => msg.role === 'user');
    //   if (lastMsg) this.prompt = lastMsg.content;
    //   event.preventDefault();
    // }
  }
  generateId(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
      const rand = (Math.random() * 16) | 0;
      const val = char === 'x' ? rand : (rand & 0x3) | 0x8;
      return val.toString(16);
    });
  }
  decodeHTMLEntities(text: string): string {
    const textarea = document.createElement('textarea');
    textarea.innerHTML = text;
    return textarea.value;
  }
  toggleSidebar() {
    this.sharedService.triggerSidebarToggle();
    // this.isSidebarVisible = !this.isSidebarVisible;
    // setTimeout(() => this.isSidebarVisible = !this.isSidebarVisible, 100);
  }
  autoResizeTextarea(textarea: HTMLTextAreaElement): void {
    textarea.style.height = 'auto';
    const newHeight = Math.min(textarea.scrollHeight, 150);
    textarea.style.height = newHeight + 'px';
    textarea.style.overflowY = textarea.scrollHeight > 150 ? 'auto' : 'hidden';
  }
  getPromptToStore() {
    console.log(this.prompt);
    sessionStorage.setItem('prompt', this.prompt);
  }
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    const windowWidth = event.target.innerWidth;
    // console.log('Window resized to:', windowWidth);
    const scroller = document.getElementsByClassName('scroller')[0];
    if (scroller) {
      const preTags = scroller.querySelectorAll('pre');
      preTags.forEach((preTag: Element) => {
        preTag.setAttribute('style', `width: ${scroller.clientWidth}px; max-width: 100%; box-sizing: border-box;`);
      });
    }
  }
  markdownContent: string = `# Sample Heading\n\nThis is **bold** text.\n\n- Item 1\n- Item 2`;
  async downloadMarkdownAsDocx(): Promise<void> {
    // Step 1: Convert markdown to HTML
    const html = await Promise.resolve(marked(this.markdownContent));
    // Step 2: Convert HTML to paragraphs
    const tempDiv: HTMLDivElement = document.createElement('div');
    tempDiv.innerHTML = html;
    const paragraphs: Paragraph[] = [];
    tempDiv.childNodes.forEach((node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const element = node as HTMLElement;
        const text = element.innerText || '';
        // You can further parse <strong>, <em> if needed
        const para = new Paragraph(text);
        paragraphs.push(para);
      }
    });
    // Step 3: Create docx Document
    const doc = new Document({
      sections: [{
        properties: {},
        children: paragraphs
      }]
    });
    // Step 4: Download
    const blob = await Packer.toBlob(doc);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'document.docx';
    a.click();
    URL.revokeObjectURL(url);
  }
  // async downloadDocx(mdInput: any) {
  //   const htmlResult = marked.parse(mdInput);
  //   const html = htmlResult instanceof Promise ? await htmlResult : htmlResult;
  //   const tempDiv = document.createElement('div');
  //   tempDiv.innerHTML = html;
  //   const contentBlocks: (Paragraph | Table)[] = [];
  //   tempDiv.childNodes.forEach((node) => {
  //     if (node.nodeType === Node.ELEMENT_NODE) {
  //       const el = node as HTMLElement;
  //       if (el.tagName === 'H1' || el.tagName === 'H2' || el.tagName === 'H3') {
  //         contentBlocks.push(
  //           new Paragraph({
  //             text: el.innerText,
  //             heading: el.tagName === 'H1' ? HeadingLevel.HEADING_1
  //               : el.tagName === 'H2' ? HeadingLevel.HEADING_2
  //                 : HeadingLevel.HEADING_3,
  //           })
  //         );
  //       }
  //       else if (el.tagName === 'P') {
  //         const runs: TextRun[] = [];
  //         el.childNodes.forEach((child) => {
  //           if (child.nodeType === Node.TEXT_NODE) {
  //             runs.push(new TextRun(child.textContent || ''));
  //           } else if (child.nodeType === Node.ELEMENT_NODE) {
  //             const childEl = child as HTMLElement;
  //             if (childEl.tagName === 'STRONG') {
  //               runs.push(new TextRun({ text: childEl.innerText, bold: true }));
  //             } else if (childEl.tagName === 'EM') {
  //               runs.push(new TextRun({ text: childEl.innerText, italics: true }));
  //             } else if (childEl.tagName === 'CODE') {
  //               runs.push(new TextRun({ text: childEl.innerText, font: "Courier New" }));
  //             } else {
  //               runs.push(new TextRun(childEl.innerText));
  //             }
  //           }
  //         });
  //         contentBlocks.push(new Paragraph({ children: runs }));
  //       }
  //       else if (el.tagName === 'UL' || el.tagName === 'OL') {
  //         el.querySelectorAll('li').forEach((li) => {
  //           const checkboxEl = li.querySelector('input[type=checkbox]') as HTMLInputElement | null;
  //           const isChecked = checkboxEl ? checkboxEl.checked : undefined;
  //           let text = li.innerText.replace(/\n/g, " ");
  //           if (isChecked !== undefined) {
  //             text = isChecked ? `☑ ${text}` : `☐ ${text}`;
  //           }
  //           contentBlocks.push(
  //             new Paragraph({
  //               text,
  //               bullet: el.tagName === 'UL' ? { level: 0 } : undefined,
  //               numbering: el.tagName === 'OL' ? { reference: "num", level: 0 } : undefined,
  //             })
  //           );
  //         });
  //       }
  //       else if (el.tagName === 'PRE') {
  //         const codeEl = el.querySelector('code');
  //         if (codeEl) {
  //           contentBlocks.push(
  //             new Paragraph({
  //               children: [
  //                 new TextRun({
  //                   text: codeEl.innerText,
  //                   font: "Courier New",
  //                 }),
  //               ],
  //             })
  //           );
  //         }
  //       }
  //       else if (el.tagName === 'TABLE') {
  //         const rows: TableRow[] = [];
  //         el.querySelectorAll("tr").forEach((tr) => {
  //           const cells: TableCell[] = [];
  //           tr.querySelectorAll("td, th").forEach((td) => {
  //             const cellEl = td as HTMLElement;
  //             cells.push(new TableCell({
  //               children: [new Paragraph(cellEl.innerText)],
  //             }));
  //           });
  //           rows.push(new TableRow({ children: cells }));
  //         });
  //         contentBlocks.push(
  //           new Table({
  //             rows,
  //             width: {
  //               size: 100,
  //               type: WidthType.PERCENTAGE,
  //             },
  //             columnWidths: [3500, 1000, 3500], // Adjust widths per column
  //           })
  //         );
  //       }
  //     }
  //   });
  //   const doc = new Document({
  //     sections: [{ children: contentBlocks }],
  //   });
  //   const blob = await Packer.toBlob(doc);
  //   saveAs(blob, "document.docx");
  // }

  // async downloadDocx(mdInput: string) {
  //   const htmlResult = marked(mdInput);
  //   const html = htmlResult instanceof Promise ? await htmlResult : htmlResult;
  //   const tempDiv = document.createElement("div");
  //   tempDiv.innerHTML = html;

  //   const contentBlocks: (Paragraph | Table)[] = [];

  //   function parseInlineContent(element: HTMLElement, format: {
  //     bold?: boolean,
  //     italics?: boolean,
  //     strike?: boolean,
  //     code?: boolean;
  //   } = {}): TextRun[] {
  //     const runs: TextRun[] = [];

  //     element.childNodes.forEach((node) => {
  //       if (node.nodeType === Node.TEXT_NODE) {
  //         const text = node.textContent || "";
  //         runs.push(new TextRun({
  //           text,
  //           bold: format.bold,
  //           italics: format.italics,
  //           strike: format.strike,
  //           font: format.code ? "Courier New" : undefined,
  //         }));
  //       } else if (node.nodeType === Node.ELEMENT_NODE) {
  //         const el = node as HTMLElement;
  //         const tag = el.tagName;

  //         const newFormat = {
  //           bold: format.bold || ["B", "STRONG"].includes(tag),
  //           italics: format.italics || ["I", "EM"].includes(tag),
  //           strike: format.strike || ["DEL", "S"].includes(tag),
  //           code: format.code || tag === "CODE",
  //         };

  //         const childRuns = parseInlineContent(el, newFormat);
  //         runs.push(...childRuns);
  //       }
  //     });

  //     return runs;
  //   }



  //   tempDiv.childNodes.forEach((node) => {
  //     if (node.nodeType !== Node.ELEMENT_NODE) return;
  //     const el = node as HTMLElement;

  //     // Headings
  //     if (["H1", "H2", "H3"].includes(el.tagName)) {
  //       const headingLevel =
  //         el.tagName === "H1"
  //           ? HeadingLevel.HEADING_1
  //           : el.tagName === "H2"
  //             ? HeadingLevel.HEADING_2
  //             : HeadingLevel.HEADING_3;

  //       contentBlocks.push(
  //         new Paragraph({
  //           heading: headingLevel,
  //           children: parseInlineContent(el),
  //         })
  //       );
  //     }

  //     // Paragraphs
  //     else if (el.tagName === "P") {
  //       contentBlocks.push(new Paragraph({ children: parseInlineContent(el) }));
  //     }

  //     // Lists
  //     else if (["UL", "OL"].includes(el.tagName)) {
  //       const isOrdered = el.tagName === "OL";
  //       const processList = (ulEl: HTMLElement, level = 0) => {
  //         ulEl.childNodes.forEach((li) => {
  //           if (
  //             li.nodeType === Node.ELEMENT_NODE &&
  //             (li as HTMLElement).tagName === "LI"
  //           ) {
  //             const liEl = li as HTMLElement;
  //             const children = parseInlineContent(liEl);
  //             contentBlocks.push(
  //               new Paragraph({
  //                 children,
  //                 bullet: !isOrdered ? { level } : undefined,
  //                 numbering: isOrdered ? { reference: "num", level } : undefined,
  //                 indent: { left: level * 500 },
  //               })
  //             );

  //             // Check for nested UL/OL
  //             liEl.childNodes.forEach((subNode) => {
  //               if (
  //                 subNode.nodeType === Node.ELEMENT_NODE &&
  //                 ["UL", "OL"].includes((subNode as HTMLElement).tagName)
  //               ) {
  //                 processList(subNode as HTMLElement, level + 1);
  //               }
  //             });
  //           }
  //         });
  //       };
  //       processList(el);
  //     }

  //     // Blockquotes
  //     else if (el.tagName === "BLOCKQUOTE") {
  //       contentBlocks.push(
  //         new Paragraph({
  //           children: parseInlineContent(el),
  //           indent: { left: 500 },
  //         })
  //       );
  //     }

  //     // Code Blocks
  //     else if (el.tagName === "PRE") {
  //       const code = el.innerText;
  //       contentBlocks.push(
  //         new Paragraph({
  //           children: [
  //             new TextRun({
  //               text: code,
  //               font: "Courier New",
  //             }),
  //           ],
  //         })
  //       );
  //     }

  //     // Horizontal Rule
  //     else if (el.tagName === "HR") {
  //       contentBlocks.push(
  //         new Paragraph({
  //           border: {
  //             bottom: {
  //               style: BorderStyle.SINGLE,
  //               size: 6,
  //               color: "auto",
  //             },
  //           },
  //         })
  //       );
  //     }

  //     // Tables
  //     else if (el.tagName === "TABLE") {
  //       const rows: TableRow[] = [];

  //       el.querySelectorAll("tr").forEach((tr) => {
  //         const cells: TableCell[] = [];

  //         tr.querySelectorAll("th, td").forEach((cell) => {
  //           const cellEl = cell as HTMLElement;
  //           const text = cellEl.innerText;

  //           cells.push(
  //             new TableCell({
  //               children: [new Paragraph({ text })],
  //             })
  //           );
  //         });

  //         rows.push(new TableRow({ children: cells }));
  //       });

  //       contentBlocks.push(
  //         new Table({
  //           rows,
  //           width: { size: 100, type: WidthType.PERCENTAGE },
  //         })
  //       );
  //     }
  //   });

  //   const doc = new Document({
  //     sections: [{ children: contentBlocks }],
  //   });

  //   const blob = await Packer.toBlob(doc);
  //   saveAs(blob, "document.docx");
  // }
  async downloadDocx(mdInput: string) {
    const html = await Promise.resolve(marked(mdInput));
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;

    const contentBlocks: (Paragraph | Table)[] = [];

    function parseInlineContent(element: HTMLElement, format: any = {}): TextRun[] {
      const runs: TextRun[] = [];

      element.childNodes.forEach((node) => {
        if (node.nodeType === Node.TEXT_NODE) {
          runs.push(new TextRun({
            text: node.textContent || "",
            bold: format.bold,
            italics: format.italics,
            strike: format.strike,
            font: format.code ? "Courier New" : undefined,
          }));
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          const el = node as HTMLElement;
          const tag = el.tagName;
          const newFormat = {
            bold: format.bold || ["STRONG", "B"].includes(tag),
            italics: format.italics || ["EM", "I"].includes(tag),
            strike: format.strike || ["S", "DEL"].includes(tag),
            code: format.code || tag === "CODE",
          };
          runs.push(...parseInlineContent(el, newFormat));
        }
      });

      return runs;
    }

    function processList(el: HTMLElement, level = 0, ordered = false) {
      el.querySelectorAll(":scope > li").forEach((li) => {
        const liClone = li.cloneNode(true) as HTMLElement;
        liClone.querySelectorAll("ul, ol").forEach(n => n.remove());

        let runs = parseInlineContent(liClone);

        const checkbox = li.querySelector("input[type='checkbox']") as HTMLInputElement | null;
        if (checkbox) {
          const prefix = checkbox.checked ? "☑ " : "☐ ";
          runs = [new TextRun(prefix), ...runs];
        }

        contentBlocks.push(new Paragraph({
          children: runs,
          numbering: {
            reference: ordered ? "ordered" : "unordered",
            level,
          },
        }));

        li.querySelectorAll(":scope > ul, :scope > ol").forEach((subList) => {
          processList(subList as HTMLElement, level + 1, subList.tagName === "OL");
        });
      });
    }


    tempDiv.childNodes.forEach((node) => {
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const el = node as HTMLElement;
      console.log("Processing element:", el.tagName);
      console.log("Element content:", el);



      // Headings
      if (["H1", "H2", "H3"].includes(el.tagName)) {
        const heading = el.tagName === "H1"
          ? HeadingLevel.HEADING_1
          : el.tagName === "H2"
            ? HeadingLevel.HEADING_2
            : HeadingLevel.HEADING_3;

        contentBlocks.push(new Paragraph({
          heading,
          children: parseInlineContent(el),
        }));
      }

      // Paragraph
      else if (el.tagName === "P") {
        contentBlocks.push(new Paragraph({
          children: parseInlineContent(el),
        }));
      }

      // Lists
      else if (el.tagName === "UL" || el.tagName === "OL") {
        processList(el, 0, el.tagName === "OL");
      }

      // Code block
      else if (el.tagName === "PRE") {
        const code = el.innerText;
        contentBlocks.push(new Paragraph({
          children: [new TextRun({ text: code, font: "Courier New" })],
        }));
      }

      // Blockquotes
      else if (el.tagName === "BLOCKQUOTE") {
        contentBlocks.push(new Paragraph({
          children: parseInlineContent(el),
          indent: { left: 500 },
        }));
      }

      // Horizontal Rule
      else if (el.tagName === "HR" || el.outerHTML.startsWith("<hr")) {
        contentBlocks.push(new Paragraph({
          border: {
            bottom: {
              style: BorderStyle.SINGLE,
              size: 6,
              color: "999999",
            },
          },
          spacing: { after: 200 },
        }));

      }

      // Table
      else if (el.tagName === "TABLE") {
        const rows: TableRow[] = [];

        el.querySelectorAll("tr").forEach((tr) => {
          const cells: TableCell[] = [];
          tr.querySelectorAll("th, td").forEach((td) => {
            cells.push(new TableCell({
              children: [new Paragraph((td as HTMLElement).innerText)],
            }));
          });
          rows.push(new TableRow({ children: cells }));
        });

        // Dynamic column widths
        const colCount = el.querySelectorAll("tr:first-child td, tr:first-child th").length;
        const columnWidths = Array(colCount).fill(10000 / colCount);

        contentBlocks.push(new Table({
          rows,
          width: { size: 100, type: WidthType.PERCENTAGE },
          columnWidths,
        }));
      }
    });

    const doc = new Document({
      numbering: {
        config: [
          {
            reference: "ordered",
            levels: Array.from({ length: 5 }, (_, level) => ({
              level,
              format: "decimal",
              text: "%".repeat(level + 1).split("").map((_, i) => `%${i + 1}`).join(".") + ".",
              alignment: AlignmentType.START,
            })),
          },
          {
            reference: "unordered",
            levels: Array.from({ length: 5 }, (_, level) => ({
              level,
              format: "bullet",
              text: "•",
              alignment: AlignmentType.START,
            })),
          },
        ]
      },
      sections: [{ children: contentBlocks }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "document.docx");
  }


  processFilesData(filesData: any[]) {
    const fileTypeOrder = ['image', 'doc', 'pdf'];
    const typeMap: { [key: string]: string; } = {
      'image/jpeg': 'image',
      'image/png': 'image',
      'image/gif': 'image',
      'application/pdf': 'pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'doc',
      'application/msword': 'doc'
    };

    const result: any = {
      filesData: {
        data: [],
        totalCount: 0,
        otherFileData: []
      },
      totalCount: filesData.length,
      otherFileData: []
    };

    const seenTypes = new Set<string>();

    for (const file of filesData) {
      const typeKey = typeMap[file.type];
      if (typeKey && !seenTypes.has(typeKey)) {
        result.filesData.data.push(file);
        seenTypes.add(typeKey);
      } else {
        result.otherFileData.push(file);
      }
    }

    // Sort result.filesData by image, doc, pdf order
    result.filesData.data.sort((a: any, b: any) => {
      const typeA = typeMap[a.type];
      const typeB = typeMap[b.type];
      return fileTypeOrder.indexOf(typeA) - fileTypeOrder.indexOf(typeB);
    });

    return result;
  }
  copyToClipboard(content: string): void {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(content).then(() => {
        // Optionally show a success message
        console.log('Copied to clipboard');
      }).catch(err => {
        console.error('Failed to copy:', err);
      });
    } else {
      // Fallback for older browsers
      const textarea = document.createElement('textarea');
      textarea.value = content;
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        console.log('Copied to clipboard');
      } catch (err) {
        console.error('Failed to copy:', err);
      }
      document.body.removeChild(textarea);
    }
  }
  msg: any[] = [];
  // sendPrompt() {
  //   this.msg = [];

  //   this.chatAIService.streamChat(this.prompt).subscribe({
  //     next: (data) => {
  //       this.msg.push(data);
  //     },
  //     complete: () => {
  //       console.log('Stream complete');
  //     },
  //     error: (err) => {
  //       console.error('Stream error:', err);
  //     }
  //   });
  // }
  responseText = '';
  eventSource: EventSource | null = null;


  ngOnDestroy(): void {
    this.eventSource?.close();
  }
}
