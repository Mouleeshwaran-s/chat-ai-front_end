import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EventSourcePolyfill } from 'event-source-polyfill';

@Injectable({
  providedIn: 'root'
})
export class ChatAiService {

  constructor(private http: HttpClient) { }
  private apiUrl = 'http://localhost:8082/api/chat/stream';

  API_URL = '';
  // getChatAIResponse(prompt: string): Promise<any> {
  //   const url = `${this.API_URL}/chatgpt`;
  //   const headers = {
  //     'Content-Type': 'application/json',
  //     'Authorization': `Bearer YOUR_API_KEY`
  //   };
  //   const body = {
  //     model: 'gpt-3.5-turbo',
  //     messages: [{ role: 'user', content: prompt }],
  //     max_tokens: 100
  //   };

  //   return this.http.post(url, body, { headers }).toPromise();
  // }
  // streamChat(prompt: string): EventSource {
  //   return new EventSource(`http://localhost:8082/api/chat/stream?prompt=${encodeURIComponent(prompt)}`);
  // }
  // streamChat(message: any): Observable<string> {
  //   const token = localStorage.getItem('access_token');

  //   return new Observable<string>((observer) => {
  //     const controller = new AbortController();

  //     fetch('http://localhost:8082/api/chat/stream', {
  //       method: 'POST',
  //       body: JSON.stringify(message),
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': `Bearer ${token}`
  //       },
  //       signal: controller.signal
  //     }).then(async (response) => {
  //       if (!response.ok || !response.body) {
  //         observer.error('Stream failed');
  //         return;
  //       }

  //       const reader = response.body.getReader();
  //       const decoder = new TextDecoder();

  //       while (true) {
  //         const { done, value } = await reader.read();
  //         if (done) break;

  //         const chunk = decoder.decode(value, { stream: true });
  //         observer.next(chunk);
  //       }

  //       observer.complete();
  //     }).catch((err) => observer.error(err));

  //     // Cleanup on unsubscribe
  //     return () => controller.abort();
  //   });
  // }
  streamChat(
    message: any,
    onChunk: (data: string) => void,
    onError: (err: any) => void
  ) {
    const token = localStorage.getItem('access_token');
    fetch(this.apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(message),
    })
      .then((response) => {
        if (!response.ok || !response.body) {
          throw new Error('Failed to connect to stream');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        const readChunk = () => {
          reader.read().then(({ done, value }) => {
            if (done) return;
            const chunkText = decoder.decode(value, { stream: true });
            buffer += chunkText;

            // Process each complete `data:` line
            const lines = buffer.split('\n');
            buffer = lines.pop() || ''; // last incomplete line goes back to buffer

            lines.forEach((line) => {
              line = line.trim();
              if (line.startsWith('data:')) {
                const jsonText = line.replace(/^data:\s*/, '');
                onChunk(jsonText);
              } else if (line !== '') {
                onChunk(line); // fallback for raw JSON lines
              }
            });

            readChunk();
          });
        };

        readChunk();
      })
      .catch(onError);
  }
  // streamChat(message: any): Observable<string> {
  //   const token = localStorage.getItem('access_token');

  //   return new Observable<string>((observer) => {
  //     fetch('http://localhost:8082/api/chat/stream', {
  //       method: 'POST',
  //       headers: {
  //         'Authorization': `Bearer ${token}`,
  //         'Content-Type': 'application/json',
  //       },
  //       body: JSON.stringify(message),
  //     })
  //       .then(response => {
  //         const reader = response.body?.getReader();
  //         const decoder = new TextDecoder('utf-8');

  //         const read = () => {
  //           if (!reader) return;
  //           reader.read().then(({ done, value }) => {
  //             if (done) {
  //               observer.complete();
  //               return;
  //             }

  //             const chunk = decoder.decode(value, { stream: true });
  //             observer.next(chunk);
  //             read(); // keep reading
  //           });
  //         };

  //         read();
  //       })
  //       .catch(err => observer.error(err));
  //   });
  // }

  createUser(user: any): Observable<any> {
    const url = `${this.API_URL}/users`;
    const headers = {
      'Content-Type': 'application/json',
    };

    return this.http.post<any>(url, user, { headers });
  }
  getUser(id: string) {
    const url = `${this.API_URL}/users/${id}`;
    const headers = {
      'Content-Type': 'application/json',
    };
    return this.http.get(url, { headers }).toPromise();
  }
  saveChat(chat: any): Observable<any> {
    const url = `${this.API_URL}/chat`;
    const headers = {
      'Content-Type': 'application/json',
    };
    return this.http.post<any>(url, chat, { headers });
  }
  saveChatHistory(chatHistory: any): Observable<any> {
    const url = `${this.API_URL}/chatHistory`;
    const headers = {
      'Content-Type': 'application/json',
    };
    return this.http.post<any>(url, chatHistory, { headers });
  }
  getUserChatHistory(id: any, session_id: any) {

    const url = `${this.API_URL}/chat/${id}/${session_id}`;
    const headers = {
      'Content-Type': 'application/json',
    };
    return this.http.get<any>(url, { headers });
  }

}
