import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { LoginService } from './service/login.service';
import { AuthService } from '../../core/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink]
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;

  showNotification = false;
  notificationMessage = '';
  notificationType: 'success' | 'error' | 'warning' | 'info' = 'success';
  private notificationTimeout: any;

  showPassword = false;

  constructor(private fb: FormBuilder, private loginService: AuthService, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: [''],
      password: ['']
    });
  }

  showToast(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    this.notificationMessage = message;
    this.notificationType = type;
    this.showNotification = true;

    setTimeout(() => {
      const progress = document.querySelector('.notification-progress') as HTMLElement;
      if (progress) {
        progress.style.transition = 'none';
        progress.style.transform = 'scaleX(0)';
        void progress.offsetWidth;
        progress.style.transition = 'transform 3s linear';
        progress.style.transform = 'scaleX(1)';
      }
    }, 10);

    clearTimeout(this.notificationTimeout);
    this.notificationTimeout = setTimeout(() => {
      this.showNotification = false;
    }, 3000);
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  onSubmit() {
    const { email, password } = this.loginForm.value;

    if (!email && !password) {
      this.showToast('Please enter both email and password.', 'info');
    } else if (!email) {
      this.showToast('Please enter your email.', 'warning');
    } else if (!password) {
      this.showToast('Please enter your password.', 'warning');
    } else {
      this.loginService.login({ username: email, password }).subscribe({
        next: (response) => {
          this.showToast('Login successful!', 'success');
          setTimeout(() => {
            this.router.navigate(['/chat']);
          }, 3000); // Redirect after 1 second
        },
        error: (error) => {
          this.showToast('Invalid credentials. Please try again.', 'error');
        }
      });
    }
  }
}
