import { Component, HostListener, OnInit } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { ChatAIComponent } from "./pages/chat-ai/chat-ai.component";
import { SharedService } from './core/service/shared.service';
import { SidebarComponent } from './pages/sidebar/sidebar.component';
import { AiChatComponent } from './pages/AiChat/AiChat.component';
import { ChatComponent } from './pages/chat/chat.component';

@Component({
  selector: 'app-root',
  imports: [ChatAIComponent, RouterModule, SidebarComponent, AiChatComponent, ChatComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'chatAI';
  sidebarClosed = false;
  toggleBtnRotated = false;

  constructor(private router: Router, private sharedService: SharedService) { }

  ngOnInit(): void {
    // console.log('AppComponent initialized with title:', this.title);
    // const generatedId = this.generateId();
    // console.log('Generated ID:', generatedId);
    // this.router.navigate(['chat', generatedId]);
  }

  toggleSidebar() {
    this.sidebarClosed = !this.sidebarClosed;
    this.toggleBtnRotated = !this.toggleBtnRotated;
    this.closeAllSubMenus();
  }

  closeAllSubMenus() {
    // Implement submenu closing logic if needed
  }

  generateId(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
      const random = (Math.random() * 16) | 0;
      const value = char === 'x' ? random : (random & 0x3) | 0x8;
      return value.toString(16);
    });
  }

}
