declare module 'pdfjs-dist';
declare module 'pdfjs-dist/build/pdf.worker.entry';
