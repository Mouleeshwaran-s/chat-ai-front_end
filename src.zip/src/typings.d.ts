declare module 'html-docx-js/dist/html-docx';
